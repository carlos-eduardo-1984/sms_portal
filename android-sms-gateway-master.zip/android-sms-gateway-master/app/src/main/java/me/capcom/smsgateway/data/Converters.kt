package me.capcom.smsgateway.data

import androidx.room.TypeConverter
import com.google.gson.GsonBuilder
import com.google.gson.JsonElement
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class Converters {
    private val gson = GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").create()

    @TypeConverter
    fun listToString(value: List<String>?): String? {
        return value?.let { gson.toJson(it) }
    }

    @TypeConverter
    fun listFromString(value: String?): List<String>? {
        return value?.let { gson.fromJson(it, Array<String>::class.java).toList() }
    }

    @TypeConverter
    fun dateToString(value: Date?): String? {
        return value?.let { DATE_FORMAT.format(it) }
    }

    @TypeConverter
    fun dateFromString(value: String?): Date? {
        if (value == null) return null
        // Try the canonical format first, then a tolerant fallback list.
        // Never let a ParseException/RuntimeException escape into LiveData.
        val parsers = listOf(DATE_FORMAT) + FALLBACK_FORMATS
        for (format in parsers) {
            try {
                format.parse(value)?.let { return it }
            } catch (_: Exception) {
                // try next format
            }
        }
        return null
    }

    @TypeConverter
    fun jsonToString(value: JsonElement?): String? {
        return value?.let { gson.toJson(it) }
    }

    @TypeConverter
    fun stringToJson(value: String?): JsonElement? {
        return value?.let { gson.fromJson(it, JsonElement::class.java) }
    }

    companion object {
        private val DATE_FORMAT =
            SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).apply {
                timeZone = TimeZone.getTimeZone("GMT")
            }

        // Accepted legacy/alternate formats (all interpreted as GMT to match the
        // canonical writer). Used only after DATE_FORMAT fails, so new rows keep
        // the exact .SSS'Z' round-trip while old rows (e.g. produced by MIGRATION_7_8
        // via strftime without milliseconds) are parsed without crashing.
        private val FALLBACK_FORMATS = listOf(
            SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", Locale.US).apply {
                timeZone = TimeZone.getTimeZone("GMT")
                isLenient = true
            },
            SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).apply {
                timeZone = TimeZone.getTimeZone("GMT")
                isLenient = true
            },
            SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).apply {
                timeZone = TimeZone.getTimeZone("GMT")
                isLenient = true
            },
            SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS", Locale.US).apply {
                timeZone = TimeZone.getTimeZone("GMT")
                isLenient = true
            },
            SimpleDateFormat("yyyy-MM-dd", Locale.US).apply {
                timeZone = TimeZone.getTimeZone("GMT")
                isLenient = true
            },
        )
    }
}