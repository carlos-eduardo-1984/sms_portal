package me.capcom.smsgateway.modules.receiver

import android.content.Context
import android.content.pm.PackageManager
import android.database.ContentObserver
import android.net.Uri
import android.os.Handler
import android.os.HandlerThread
import androidx.core.content.ContextCompat
import me.capcom.smsgateway.modules.logs.LogsService
import me.capcom.smsgateway.modules.logs.db.LogEntry
import me.capcom.smsgateway.modules.receiver.data.InboxMessage
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject

class MmsContentObserver : KoinComponent {
    private val context: Context by inject()
    private val storage: StateStorage by inject()
    private val receiverSvc: ReceiverService by inject()
    private val logsService: LogsService by inject()

    private var handlerThread: HandlerThread? = null
    private var observer: ContentObserver? = null

    fun start() {
        if (observer != null) {
            return
        }

        if (!canReadSms()) {
            logsService.insert(
                LogEntry.Priority.WARN,
                MODULE_NAME,
                "MMS inbox observer not started because READ_SMS is not granted",
            )
            return
        }

        // Initialize high-water mark to current max ID if not set
        if (storage.mmsLastProcessedID == 0L) {
            storage.mmsLastProcessedID = queryMaxMmsId()
        }

        val thread = HandlerThread("MmsContentObserver").apply { start() }
        handlerThread = thread
        val handler = Handler(thread.looper)

        val obs = object : ContentObserver(handler) {
            override fun onChange(selfChange: Boolean) {
                super.onChange(selfChange)
                processNewMessages()
            }
        }
        observer = obs

        context.contentResolver.registerContentObserver(
            Uri.parse("content://mms"),
            true,
            obs,
        )

        // Catch up rows that arrived while the app process was stopped or before
        // READ_SMS was granted. ContentObserver callbacks are edge-triggered, so
        // already-inserted MMS rows would otherwise remain pending forever.
        handler.post { processNewMessages() }
    }

    fun stop() {
        observer?.let { context.contentResolver.unregisterContentObserver(it) }
        observer = null
        handlerThread?.quitSafely()
        handlerThread = null
    }

    private fun queryMaxMmsId(): Long {
        if (!canReadSms()) return 0

        val cursor = try {
            context.contentResolver.query(
                Uri.parse("content://mms"),
                arrayOf("_id"),
                null, null,
                "_id DESC LIMIT 1"
            )
        } catch (e: SecurityException) {
            logsService.insert(
                LogEntry.Priority.WARN,
                MODULE_NAME,
                "Unable to initialize MMS inbox high-water mark because provider access was denied",
                mapOf("error" to (e.message ?: e.toString())),
            )
            return 0
        } ?: return 0

        return cursor.use { c ->
            if (c.moveToFirst()) c.getLong(0) else 0
        }
    }

    private fun processNewMessages() {
        if (!canReadSms()) {
            logsService.insert(
                LogEntry.Priority.WARN,
                MODULE_NAME,
                "Skipping MMS inbox processing because READ_SMS is not granted",
            )
            return
        }

        val mark = storage.mmsLastProcessedID
        // msg_type 132 = retrieve-conf (fully downloaded), msg_box 1 = inbox
        val cursor = try {
            context.contentResolver.query(
                Uri.parse("content://mms"),
                arrayOf("_id"),
                "_id > ? AND m_type = 132 AND msg_box = 1",
                arrayOf(mark.toString()),
                "_id ASC"
            )
        } catch (e: SecurityException) {
            logsService.insert(
                LogEntry.Priority.WARN,
                MODULE_NAME,
                "Skipping MMS inbox processing because provider access was denied",
                mapOf("error" to (e.message ?: e.toString())),
            )
            return
        } ?: return

        cursor.use { c ->
            while (c.moveToNext()) {
                val mmsId = c.getLong(0)
                try {
                    processMmsDownloaded(mmsId)
                } catch (e: Exception) {
                    logsService.insert(
                        LogEntry.Priority.ERROR,
                        MODULE_NAME,
                        "Failed processing downloaded MMS (id=$mmsId)",
                        mapOf("mmsId" to mmsId, "error" to (e.message ?: e.toString())),
                    )
                }
                // Always advance mark to prevent one corrupt MMS from blocking the pipeline
                storage.mmsLastProcessedID = mmsId
            }
        }
    }

    private fun processMmsDownloaded(mmsId: Long) {
        // The content observer fires when the parent MMS row is inserted, but the
        // child addr/part sub-tables may not be populated yet by the telephony
        // framework. Retry a few times with a short delay to wait for them.
        var message: MmsContentReader.MmsMessage? = null
        for (attempt in 1..MMS_DOWNLOAD_MAX_RETRIES) {
            message = MmsContentReader.read(context, mmsId) ?: return
            val needsRetry = message.sender == "unknown" || (message.body.isNullOrBlank() && message.attachments.isEmpty())
            if (!needsRetry) break
            if (attempt < MMS_DOWNLOAD_MAX_RETRIES) {
                logsService.insert(
                    LogEntry.Priority.DEBUG,
                    MODULE_NAME,
                    "MMS content incomplete (id=$mmsId, sender=${message.sender}, attachments=${message.attachments.size}), " +
                            "retrying in ${MMS_DOWNLOAD_RETRY_DELAY_MS}ms (attempt $attempt/$MMS_DOWNLOAD_MAX_RETRIES)",
                )
                Thread.sleep(MMS_DOWNLOAD_RETRY_DELAY_MS)
            }
        }

        message?.let { msg ->
            receiverSvc.process(
                context,
                InboxMessage.MMS(
                    mmsId.toString(),
                    msg.body,
                    msg.subject,
                    msg.attachments.map {
                        InboxMessage.MMS.Attachment(
                            it.partId,
                            it.contentType,
                            it.name,
                            it.size,
                            it.data
                        )
                    },
                    msg.sender,
                    msg.date,
                    msg.subscriptionId
                ),
                true,
            )
        }
    }

    private fun canReadSms(): Boolean = ContextCompat.checkSelfPermission(
        context,
        android.Manifest.permission.READ_SMS,
    ) == PackageManager.PERMISSION_GRANTED

    companion object {
        private const val TAG = "MmsContentObserver"
        private const val MMS_DOWNLOAD_MAX_RETRIES = 3
        private const val MMS_DOWNLOAD_RETRY_DELAY_MS = 1500L
    }
}
